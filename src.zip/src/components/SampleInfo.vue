<template>
  <div class="sample-info">
    <div v-if="!showPreview">
      <h2 class="title">住宅厨房和卫生间排烟（气）道</h2>
      <div class="divider"></div>

      <div class="sample-content">
        <div class="info-item">
          <span class="label">样品名称：</span>
          <span class="value">{{ sampleData.name }}</span>
        </div>
        <div class="info-item">
          <span class="label">样品编号：</span>
          <span class="value">{{ sampleData.code }}</span>
        </div>
        <div class="info-item">
          <span class="label">检验状态：</span>
          <span class="value">{{ sampleData.status }}</span>
        </div>
        <div class="info-item">
          <span class="label">检验类型：</span>
          <span class="value">{{ sampleData.type }}</span>
        </div>
        <div class="info-item">
          <span class="label">样品状态：</span>
          <span class="value">{{ sampleData.condition }}</span>
        </div>
        <div class="info-item">
          <span class="label">委托单位：</span>
          <span class="value">{{ sampleData.client }}</span>
        </div>
        <div class="info-item">
          <span class="label">受检单位：</span>
          <span class="value">{{ sampleData.inspectedUnit }}</span>
        </div>
        <div class="info-item">
          <span class="label">生产单位：</span>
          <span class="value">{{ sampleData.manufacturer }}</span>
        </div>
        <div class="info-item">
          <span class="label">完成期限：</span>
          <span class="value">{{ sampleData.deadline }}</span>
        </div>
      </div>

      <div class="action-buttons">
        <button class="view-btn" @click="showPdfPreview">报告查看</button>
      </div>
    </div>

    <!-- PDF 预览部分 -->
    <div v-if="showPreview" class="pdf-modal">
      <div class="toolbar">
        <div class="tool-group">
          <button
            class="tool-btn arrow-btn"
            :disabled="currentPage <= 1"
            @click="prevPage"
          >‹</button>
          <div class="page-input">
            <input
              type="number"
              v-model.number="currentPage"
              @change="goToPage"
              :min="1"
              :max="numPages"
            />
            <span class="page-separator">/</span>
            <span class="total-pages">{{ numPages }}</span>
          </div>
          <button
            class="tool-btn arrow-btn"
            :disabled="currentPage >= numPages"
            @click="nextPage"
          >›</button>
        </div>
      </div>
      <pdf
        ref="pdfViewer"
        :src="pdfUrl"
        @loaded="onPdfLoaded"
        @page-change="currentPage = $event"
      ></pdf>
    </div>
  </div>
</template>

<script>
// import VueOfficePdf from '@vue-office/pdf'
import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.entry';
export default {
  name: 'SampleInfo',
  components: {},
  data() {
    return {
      pdfUrl: '/A.pdf',
      showPreview: false,
      pdfDoc: null,
      currentPage: 1,
      numPages: 0,
      loading: false,
      scale: 1.0,
      autoScale: true,
      preloaded: false,
      sampleData: {
        name: '住宅厨房和卫生间排烟（气）道',
        code: '2024JX10036',
        status: '已检',
        type: '委托检验（一般委托）',
        condition: '外观无异常',
        client: '合肥市包河区重点工程建设管理中心',
        inspectedUnit: '安徽惠丰环保科技有限公司',
        manufacturer: '安徽惠丰环保科技有限公司',
        deadline: '2025-01-28'
      },
    }
  },

  methods: {

    showPdfPreview() {
      this.showPreview = true;
      this.currentPage = 1;
      this.loadPdf();
    },

    async loadPdf() {
      pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;
      
      try {
        this.pdfDoc = await pdfjsLib.getDocument(this.pdfUrl).promise;
        this.numPages = this.pdfDoc.numPages;
        this.renderPage(this.currentPage);
      } catch (error) {
        console.error('Error loading PDF:', error);
      }
    },

    async renderPage(num) {
      const page = await this.pdfDoc.getPage(num);
      const viewport = page.getViewport({ scale: this.scale });
      const canvas = this.$refs.pdfCanvas;
      const context = canvas.getContext('2d');
      
      canvas.height = viewport.height;
      canvas.width = viewport.width;

      const renderContext = {
        canvasContext: context,
        viewport: viewport
      };
      
      await page.render(renderContext).promise;
    },

    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
        this.renderPage(this.currentPage);
      }
    },

    nextPage() {
      if (this.currentPage < this.numPages) {
        this.currentPage++;
        this.renderPage(this.currentPage);
      }
    },

    goToPage() {
      if (this.currentPage < 1) {
        this.currentPage = 1;
      } else if (this.currentPage > this.numPages) {
        this.currentPage = this.numPages;
      }
      this.renderPage(this.currentPage);
    },

  }
}
</script>

<style scoped>
.sample-info {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.title {
  font-size: 18px;
  color: #333;
  text-align: center;
  margin: 0;
  padding: 10px 0;
  font-weight: normal;
}

.divider {
  height: 2px;
  background: #2196f3;
  margin: 10px 0 20px;
}

.sample-content {
  padding: 0 15px;
}

.info-item {
  margin: 12px 0;
  line-height: 1.6;
  font-size: 14px;
}

.label {
  color: #666;
  display: inline-block;
  width: 85px;
  text-align: right;
  margin-right: 10px;
}

.value {
  color: #333;
}

.action-buttons {
  text-align: center;
  margin-top: 20px;
  margin-bottom: 10px;
}

.view-btn {
  background: #f90;
  color: white;
  border: none;
  padding: 8px 24px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}

.view-btn:hover {
  background: #ff8c00;
}

/* PDF 预览弹窗样式 */
.pdf-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  z-index: 1000;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.pdf-container {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  max-width: 90%;
  max-height: 90%;
  overflow: auto;
}

.toolbar {
  background: #4a4a4a;
  padding: 12px 20px;
  display: flex;
  justify-content: flex-start;
}

.tool-group {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-left: 15px;
}

.tool-btn {
  background: none;
  border: none;
  color: #fff;
  padding: 0;
  width: 24px;
  height: 24px;
  cursor: pointer;
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Arial, sans-serif;
  line-height: 1;
}

.menu-btn {
  font-size: 20px;
  padding-top: 2px;
}

.arrow-btn {
  font-size: 16px;
}

.tool-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.page-input {
  color: #fff;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 3px;
}

.page-input input {
  width: 24px;
  background: transparent;
  border: none;
  color: #fff;
  font-size: 14px;
  text-align: center;
  padding: 2px;
  border-bottom: none;
}

.page-input input:focus {
  outline: none;
}

/* 移除输入框的上下箭头 */
.page-input input::-webkit-inner-spin-button,
.page-input input::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

.page-input input[type=number] {
  -moz-appearance: textfield;
}

.modal-body {
  flex: 1;
  overflow: hidden;
  background: #000;
  position: relative;
}

.pdf-container {
  padding: 20px;
  background: #000;
  height: 100%;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  position: relative;
}

.pdf-viewer {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

.pdf-viewer canvas {
  max-width: 100%;
  height: auto !important;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  background: #fff;
}

@media screen and (max-width: 768px) {
  .tool-btn {
    width: 20px;
    height: 20px;
  }

  .menu-btn {
    font-size: 18px;
  }

  .arrow-btn {
    font-size: 14px;
  }

  .page-input {
    font-size: 12px;
  }

  .page-input input {
    font-size: 12px;
    width: 20px;
  }

  .page-separator,
  .total-pages {
    font-size: 12px;
  }
}

.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1001;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 3px solid #333;
  border-top: 3px solid #fff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
}
</style>
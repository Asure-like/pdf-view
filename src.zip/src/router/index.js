import Vue from 'vue'
import VueRouter from 'vue-router'
import SampleInfo from '../components/SampleInfo.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'sample',
    component: SampleInfo
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router 